### Version History

### 1.2 (December 20 2015)

1. Fixed directory includes from vstacklet-trusty script 
2. Added new security profiles
  1. blocking bad user agents
  2. php easter eggs
  3. file injection attacks

### 0.2 (December 19 2015)

+ Modified default.conf template to now have custom changeable includes from vstacklet-trusty script

### 0.1 (December 19 2015)

+ Alpha pre release
