# [VStacklet Server Configs](https://github.com/JMSDOnline/vstacklet-server-configs)

**Note:** The rules, configurations and policies within this package are branched from
and are actively maintained by their respective owners [h5gp](https://github.com/h5bp/).
I have done nothing more than modified the directory structures as well as added a
few rules and configurations that are to my personal requirements when setting up
managed clients servers. I have additionally modified the included package to be more
http/2 friendly. Understand, that this file and package are not supported by h5gp
developers, nor will I include support if you use this file and encounter any errors
on your server environments.

## License

[MIT License](LICENSE.md)
